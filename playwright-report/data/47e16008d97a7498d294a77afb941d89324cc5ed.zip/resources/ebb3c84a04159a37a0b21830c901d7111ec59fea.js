(function(){
  window['optimizely'] = window['optimizely'] || [];
  window['optimizely'].push(['activateGeoDelayedExperiments', {
    'location':{
      'city': "QUEENS",
      'continent': "NA",
      'country': "US",
      'region': "NY",
      'dma': "501"
    },
    'ip':"108.30.43.175"
  }]);
})

()

;